function check(){
	//用户名
    var username=document.getElementById("user-name").value;
    if(username.length<1||username.length>10){
        document.getElementById("user-name-alert").innerHTML = "用户名应为1-10位！";
        document.getElementById("user-name-alert").className = 'alert-show';
        return false;
    }
    else {
        document.getElementById("user-name-alert").innerHTML = "";
        document.getElementById("user-name-alert").className = 'alert';
    }
    //密码
    var password=document.getElementById("password").value;
    if(password.length<6||password.length>16){
        document.getElementById("password-alert").innerHTML = "密码长度应为6-16位！";
        document.getElementById("password-alert").className = 'alert-show';
        return false;
    }
    else {
        document.getElementById("password-alert").innerHTML = "";
        document.getElementById("password-alert").className = 'alert';
    }
    //重复输入密码
    if(password!=document.getElementById("repassword").value){
        document.getElementById("repassword-alert").innerHTML = "密码不一致，请检查并重新输入！";
        document.getElementById("repassword-alert").className = 'alert-show';
        return false;
    }
    else {
        document.getElementById("repassword-alert").innerHTML = "";
        document.getElementById("repassword-alert").className = 'alert';
    }
    //手机号码
    if(!document.getElementById("tellphone").value.match(/^(1|1|1)[0-9]{10}$/)){
        document.getElementById("tellphone-alert").innerHTML = "手机号码格式错误！";
        document.getElementById("tellphone-alert").className = 'alert-show';
        return false;
    }
    else {
        document.getElementById("tellphone-alert").innerHTML = "";
        document.getElementById("tellphone-alert").className = 'alert';
    }
    window.location.href='work_zhuce_success.html';
    return true;
}